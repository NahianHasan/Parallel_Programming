#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <omp.h>

#define ROWS 1600
#define COLS 1600

void printArray(double* a, int rows, int cols) {
	int i,j;
	for (i=0; i<rows; i++) {
		for (j=0; j<cols; j++) {
			printf("%.2f ", *(a + i*cols + j));
		}
		printf("\n");
	}
	printf("\n\n\n");
}

double* makeArray(int rows, int cols) {
	double* arr = (double*) malloc(rows*cols*sizeof(double));
	int r,c;
	for (r=0; r<rows; r++) {
		for (c=0; c<cols; c++) {
			*(arr + r*cols + c) = (double) (rows*c + c);
		}
	}

	return arr;
}

int min(int i, int j) {
	return i<j ? i : j;
}

void openmp_mm(double* a, double* b, double* c, int stripeSize, int NUM_THREADS){
	int i,j,k,t;
	double sum;
	#pragma omp parallel for
	for (t=0; t<NUM_THREADS; t++){
		for (i=t*stripeSize; i<min(t*stripeSize+stripeSize,ROWS); i++){
			for (j=0; j<COLS; j++){
				sum = 0;
				for (k=0;k<COLS;k++){
					sum += a[i*COLS+k]*b[k*ROWS+j];
				}
				c[i*COLS+j] = sum;
			}
		}
	}
}

int main (int argc, char *argv[]) {
	int NUM_THREADS =  1;
	int i,j,t,k;
	const int stripeSize = COLS/NUM_THREADS;
	printf("Number of Threads = %d\nStripe Size = %d\n",NUM_THREADS,stripeSize);
	double start, end;

	double* a = makeArray(ROWS, COLS);
	double* b = makeArray(ROWS, COLS);
	double* c = makeArray(ROWS, COLS);
	

	
	clock_t timer = -clock( );
	for (t=0; t<NUM_THREADS; t++) {
		for (i=t*stripeSize; i<min(t*stripeSize+stripeSize, ROWS); i++) {
			for (j=0; j<COLS; j++) {
				double comp = 0.;
				for (k=0; k<COLS; k++) {
					comp += *(a + i*COLS + k) * *(b + k*COLS + j);
				}
				*(c + i*COLS + j) = comp;
			}
		}
	}
	double timeTaken = (timer + clock( ))/CLOCKS_PER_SEC;
	printf("Sequential Operation : time taken for matrix multiply: %f \n", timeTaken);
	

	start = omp_get_wtime();
	openmp_mm(a, b, c, stripeSize, NUM_THREADS);
	end = omp_get_wtime();
	printf("Openmp Operation : time taken for matrix multiply: %f \n", end-start);
	printArray(c,ROWS,COLS);
}

