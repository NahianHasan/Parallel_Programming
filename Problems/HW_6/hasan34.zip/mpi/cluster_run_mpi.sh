#!/bin/bash
# FILENAME:  cluster_run.sh

#SBATCH -A scholar

#SBATCH --nodes=2
#SBATCH --ntasks-per-node=20
#SBATCH --time=00:5:00
#SBATCH --export=ALL
#SBATCH --job-name 'ECE_563_HW6'
#SBATCH --output='mm_mpi.out'
#SBATCH --error='mm_mpi.out'


module load openmpi

mpicc mm_mpi.c -o mm_mpi
echo "Code Compilation Successful"
#Please change the number of threads inside the program main function as well.
srun -n 40 ./mm_mpi

wait
echo "Job Completed"

