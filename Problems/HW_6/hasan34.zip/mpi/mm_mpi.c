#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <mpi.h>

#define ROWS 1600
#define COLS 1600

void printArray(double* a, int rows, int cols) {
	int i,j;
	for (i=0; i<rows; i++) {
		for (j=0; j<cols; j++) {
			printf("%.2f ", *(a + i*cols + j));
		}
		printf("\n");
	}
	printf("\n\n\n");
}

double* makeArray(int rows, int cols) {
	double* arr = (double*) malloc(rows*cols*sizeof(double));
	int r,c;
	for (r=0; r<rows; r++) {
		for (c=0; c<cols; c++) {
			*(arr + r*cols + c) = (double) (rows*c + c);
		}
	}

	return arr;
}

int min(int i, int j) {
	return i<j ? i : j;
}

void mpi_mm(double* a, double* b, double* c, int stripeSize, int rank){
	int i,j,k,t;
	double sum;
	MPI_Datatype blocka, blocktypea;
	double* temp_a = makeArray(stripeSize, COLS);
	double* temp_c = makeArray(stripeSize, COLS);

	MPI_Type_vector(stripeSize,COLS,COLS,MPI_DOUBLE,&blocka);
	MPI_Type_commit(&blocka);
	MPI_Type_create_resized(blocka,0,stripeSize*COLS*sizeof(double),&blocktypea);
	MPI_Type_commit(&blocktypea);
	MPI_Scatter(a,1,blocktypea,temp_a,stripeSize*COLS,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Bcast(b,ROWS*COLS,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);

	for (i=0; i<stripeSize; i++){
		for (j=0; j<COLS; j++){
			sum = 0;
			for (k=0;k<COLS;k++){
				sum += temp_a[i*COLS+k]*b[k*ROWS+j];
			}
			temp_c[i*COLS+j] = sum;
		}
	}
	MPI_Barrier(MPI_COMM_WORLD);
	//MPI_Reduce(&c,c,stripeSize*COLS,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);//we can reduce bu sum operation as the noninterest entries of c matrix in each process are zeros.
	MPI_Gather(temp_c,stripeSize*COLS,MPI_DOUBLE,c,stripeSize*COLS,MPI_DOUBLE,0,MPI_COMM_WORLD);
	/*

	*/
}

int main (int argc, char *argv[]) {
	int NUM_THREADS =  40;
	const int stripeSize = COLS/NUM_THREADS;

	double start, end;

	double* a = makeArray(ROWS, COLS);
	double* b = makeArray(ROWS, COLS);
	double* c = makeArray(ROWS, COLS);

	/*
	clock_t timer = -clock( );
	for (int t=0; t<NUM_THREADS; t++) {
		for (int i=t*stripeSize; i<min(t*stripeSize+stripeSize, ROWS); i++) {
			for (int j=0; j<COLS; j++) {
				double comp = 0.;
				for (int k=0; k<COLS; k++) {
					comp += *(a + i*COLS + k) * *(b + k*COLS + j);
				}
				*(c + i*COLS + j) = comp;
			}
		}
	}
	double timeTaken = (timer + clock( ))/CLOCKS_PER_SEC;
	printf("Sequential Operation : time taken for matrix multiply: %f \n", timeTaken);
	*/

	int rank;//mpi process id
	int numP;//number of MPI processes
	int tag1 = 1;
	int tag2 = 2;
	//MPI_Request reqs[NUM_THREADS];
	//MPI_Status stats[NUM_THREADS];


	MPI_Init(&argc, &argv);
	
	MPI_Comm_size(MPI_COMM_WORLD, &numP);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Barrier(MPI_COMM_WORLD);
	start = MPI_Wtime();
	mpi_mm(a,b,c,stripeSize,rank);
	MPI_Barrier(MPI_COMM_WORLD);
	end = MPI_Wtime();
	MPI_Finalize();
	
	if (rank==0){
		printf("Number of Threads = %d\nStripe Size = %d\n",NUM_THREADS,stripeSize);
		printf("MPI Operation : time taken for matrix multiply: %f \n", end-start);
		printArray(a,ROWS,COLS);
		printArray(b,ROWS,COLS);
		printArray(c,ROWS,COLS);
	}
}

